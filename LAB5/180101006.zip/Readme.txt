PART A:
Each line of the file TestCasesPartA.txt contains a seperate test case.
1. To run use the command in terminal: "gprolog --consult-file sqrt.pl"
2. To see output Copy one of the test cases from the file "TestCasesPartA.txt"
3. To run on custom input use the command in prolog console: "findsqrt(X,Accuracy)." where X is input Number and Accuracy is largest value of error allowed. X should be greater than equal to 0 and Accuracy should be strictly greater than 0.

PART B:
Each line of the file TestCasesPartB.txt contains a seperate test case.
1. To run use the command in terminal: "gprolog --consult-file sublst.pl"
2. To see output Copy one of the test cases from the file "TestCasesPartB.txt"
3. To run on custom input use the command in prolog console: "sublst(A,B)." where list A is checked to be sublist of list B.

