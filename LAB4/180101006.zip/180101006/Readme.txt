Each line of file TestCases.txt contains a seperate test case
1. To run use the command: "runhaskell lab4.hs" 
                                    or
                           "ghci lab4.hs" and then run "main" in the interactive console
2. To see output Copy one of the test cases from the file "TestCases.txt" or Type the comma seperated list of Integers (without space)
   Example Input: 