PART A:
1. The file partAtest.txt contains 10 test cases for testing square root funtion
2. To run test cases use the command: "ghci partA.hs < partAtest.txt"
3. To give custom input load partA.hs file using command: ":load partA.hs" and then run: "cusSqrt n" where n is the input number

PART B:
1. The file partBtest.txt contains 10 test cases for testing fibonacci funtion
2. To run test cases use the command: "ghci partB.hs < partBtest.txt"
3. To give custom input load partB.hs file using command: ":load partB.hs" and then run: "fib n" where n is the input number

PART C:
1. The file partCtest.txt contains 10 test cases for testing quick sort funtion
2. To run test cases use the command: "ghci partC.hs < partCtest.txt"
3. To give custom input load partC.hs file using command: ":load partC.hs" and then run: "qsort y" where y is the input array
    Example: qsort [1,5,3]
